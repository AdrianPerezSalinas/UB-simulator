from setuptools import setup
setup(name='ub_simulator',
version='0.1',
description='Testing installation of Package',
url='#',
author='malhar',
author_email='adrian.perez@bsc.com',
license='??',
packages=['ub_simulator'],
zip_safe=False)
